public class New {
    public static void main(String[] arg){
    System.out.println("ads");
    return;
}
}
